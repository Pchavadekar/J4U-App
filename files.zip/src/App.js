import React from 'react';

function App() {
  return (
    <div style={{ fontFamily: 'sans-serif', textAlign: 'center', marginTop: 50 }}>
      <h1>Welcome to J4U-App</h1>
      <p>This is the landing page for your new React-powered website.</p>
      <p>Edit <code>src/App.js</code> to get started!</p>
    </div>
  );
}

export default App;